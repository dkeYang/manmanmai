$(function(){

var sitenavbar = "<div id=\"site-navbar\" style=\"position: absolute; top: -4px; left: -3px; border: 0; z-index: 2000;padding:0;margin:0;\">" +
			"<a href=\"/\" title=\"返回首页\" style=\"background:none;\">" +
				"<img src=\"/p/return-back.png\" style=\"padding:0;margin:0;border:0; -webkit-box-shadow: none;-moz-box-shadow: none;box-shadow: none;\">"+
			"</a>"+
		"</div>";

	$("body").append(sitenavbar);

});


var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F3d8e7fc0de8a2a75f2ca3bfe128e6391' type='text/javascript'%3E%3C/script%3E"));

//全局统计代码
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F079fac161efc4b2a6f31e80064f14e82' type='text/javascript'%3E%3C/script%3E"));
